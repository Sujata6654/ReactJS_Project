import Search from './components/search/Search.js';

function App() {
  return (
    <div className="App">
      <Search />
    </div>
  );
}

export default App;
